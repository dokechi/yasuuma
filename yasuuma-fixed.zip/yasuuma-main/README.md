# yasuuma（ミニ株×株主優待まとめ）

このリポジトリは GitHub Pages で公開する静的サイトです。

- `index.html`：優待一覧（今月 / 10万円未満 / 1株）
- `data.json`：優待データ（株価/必要資金は自動更新）
- `money.html` / `money.json`：固定費（スマホ/保険）導線

---

## 公開（GitHub Pages）

1. リポジトリの **Settings**
2. **Pages**
3. Branch を `main` / `(root)` にして Save

---

## 株価の自動更新（GitHub Actions）

`.github/workflows/update_prices.yml` が平日 18:17（JST）に動きます。
まずは手動で1回動かして動作確認してください。

### 重要：書き込み権限の設定（これが無いと data.json が更新されません）

1. リポジトリの **Settings**
2. **Actions → General**
3. **Workflow permissions** を **Read and write permissions** に変更して Save

### 手動実行（おすすめ：最初に必ず実行）

1. リポジトリ上部の **Actions**
2. 左側の **Update stock prices**
3. **Run workflow** → `main` のまま実行

成功すると `data.json` の `pricePerShareYen` / `needMoneyPerkYen` が `null` から数字に変わり、コミットが作られます。

---

## データ更新（優待の追加）

`data.json` を更新するか、CSV/Excelから生成して差し替えてください。

最低限必要なキー（1件あたり）：
- `code`（4桁）
- `name`
- `recordMonth`（例：`3月` / `3月・9月`）
- `minSharesForPerk`（1 or 100 etc）
- `perk`
- `category`
- `sourceUrl`
